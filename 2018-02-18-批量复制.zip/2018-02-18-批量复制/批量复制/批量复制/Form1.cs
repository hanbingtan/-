﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 批量复制
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            fileDialog.Multiselect = true;
            fileDialog.Title = "请选择文件";
            fileDialog.Filter = "excel文件|*.xls;*.xlsx";
            fileDialog.Multiselect = false;//不允许同时选择多个文件 
            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                string file = fileDialog.FileName;
                this.textBoxExcel.Text = file;
                //MessageBox.Show("已选择文件:" + file, "选择文件提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择源文件夹";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                this.textBoxS.Text= foldPath;
                
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择目标文件夹";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                this.textBoxD.Text = foldPath;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(ExcelCopy(this.textBoxExcel.Text, false))
            {
                MessageBox.Show("拷贝成功", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        /// <summary>
        /// ExcelCopy
        /// </summary>
        /// <param name="sheetName">excel工作薄sheet的名称</param>
        /// <param name="isFirstRowColumn">第一行是否是DataTable的列名</param>
        /// <returns>bool</returns>
        public bool ExcelCopy(string sheetName, bool isFirstRowColumn)
        {
            ISheet sheet = null;
            FileStream fs;
            string fileName = this.textBoxExcel.Text;
            IWorkbook workbook = null;
            string sfile = null;
            string dfile = null;
            int startRow = 0;
            try
            {
                fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                if (fileName.IndexOf(".xlsx") > 0) // 2007版本
                    workbook = new XSSFWorkbook(fs);
                else if (fileName.IndexOf(".xls") > 0) // 2003版本
                    workbook = new HSSFWorkbook(fs);

                if (sheetName != null)
                {
                    sheet = workbook.GetSheet(sheetName);
                    if (sheet == null) //如果没有找到指定的sheetName对应的sheet，则尝试获取第一个sheet
                    {
                        sheet = workbook.GetSheetAt(0);
                    }
                }
                else
                {
                    sheet = workbook.GetSheetAt(0);
                }
                if (sheet != null)
                {
                    //第一行
                    if (isFirstRowColumn)startRow = sheet.FirstRowNum + 1;
                    else startRow = sheet.FirstRowNum;

                    //最后一行的标号
                    int rowCount = sheet.LastRowNum;
                    for (int i = startRow; i <= rowCount; ++i)
                    {
                        IRow row = sheet.GetRow(i);
                        if (row == null) continue; //没有数据的行默认是null　　　　　　　
                        sfile = row.GetCell(0).StringCellValue;
                        dfile = row.GetCell(1).StringCellValue;
                        if(!FileCopy(this.textBoxS.Text, sfile, this.textBoxD.Text, dfile))
                        {
                            return false;
                        }
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="spath"></param>
        /// <param name="sfilename"></param>
        /// <param name="dpath"></param>
        /// <param name="dfilename"></param>
        bool FileCopy(string spath, string sfilename,string dpath,string dfilename)
        {
            if (Directory.Exists(spath) == false)//如果不存在file文件夹
            {
                MessageBox.Show("不存在源文件夹"+spath, "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            if (Directory.Exists(dpath) == false)//如果不存在file文件夹
            {
                MessageBox.Show("不存在目标文件夹" + dpath, "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            string sfile = spath + "\\" + sfilename;
            if (!File.Exists(sfile))
            {
                return true;
            }
            string dfile = dpath + "\\" + dfilename;
            System.IO.File.Copy(sfile, dfile, true);
            return true;
        }
    }
}
